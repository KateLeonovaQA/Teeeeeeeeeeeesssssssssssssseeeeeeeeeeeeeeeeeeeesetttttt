---
name: images-video-audio
description: Create and edit images, generate short videos, turn text into spoken audio, and transcribe audio to text, through the model gateway. Use when the user wants a picture, logo, diagram, mockup, an edit to an image they have, a short video clip, a transcript of a recording, or something read out loud as a voice message.
---

## Images, video and audio

The helpers live in `/workspace/ninja/utils/`. They find the gateway and its
credentials themselves — nothing to configure. Run everything from
`/workspace/ninja`.

### Create an image from text

```bash
python -m utils.images generate -o logo.png \
  "A flat minimal logo of a paper plane, single colour, plain background"
```

| Option | Values |
|---|---|
| `--size` | `1024x1024` (default), `1024x1536` portrait, `1536x1024` landscape, `2048x2048`, `auto` |
| `--quality` | `low`, `medium`, `high` — use `high` for text, charts, fine detail |
| `--model` | `gpt-image` (default), `gemini-image` (alternative provider) |

From Python: `from utils.images import generate_image`.

### Edit or combine images

Takes up to 16 reference images. Number them in the prompt ("Image 1", "Image
2", …) and say what must stay the same, or the model will drift.

```bash
python -m utils.images edit --ref chair.png --ref cat.png -o cat_on_chair.png \
  "Image 1 is a wooden chair. Image 2 is a tabby cat. Put the cat on the chair. Keep the chair's design and the cat's markings unchanged."
```

`--ref-dir ./refs/` uses every image in a folder, in alphabetical order. Use this
for style transfer, compositing, swapping text or colours, and localising an
existing design.

From Python: `from utils.images import edit_image`.

### Turn text into speech

```bash
python -m utils.speech "Good morning — here's your daily summary." -o brief.mp3
python -m utils.speech --file script.txt -o script.mp3 --voice onyx
```

`--voice` picks the speaker: `alloy` (default), `amber`, `ash`, `august`,
`blue`, `coral`, `lily`, `onyx`, `sage`, `verse`. Output is always MP3.

Where the words come from:

- **The user gave you the text** — pass it as the argument. Past a sentence or
  two, write it to a file and use `--file` instead; that avoids fighting the
  shell over quotes, apostrophes and newlines.
- **The text is in a file they sent** — `.txt` or `.md` go straight to `--file`.
  For a PDF, use the pdf skill to extract the text first, then read the result.
- **There is no text yet** — write it yourself, save it to a file, and show it
  to the user before you generate the audio. Fixing a wrong script costs one
  message; regenerating the audio costs money and a wait.

**One request holds 4,500 characters**, roughly four minutes of speech. Longer
text has to be split into several files — break it at paragraph or chapter
boundaries, never mid-sentence, and number the output files. Aim well under the
limit rather than right at it, so an uneven split doesn't push a part over.
Before you start on anything book-sized, tell the user how many files and how
long it will be and let them decide; each part costs money.

Speaks 70+ languages and picks the language up from the text itself, so no
setting to change. The voices above are English-trained, so other languages come
out with a slight English accent — say so if the user cares, rather than
pretending it will sound native.

From Python: `from utils.speech import speak`.

### Transcribe audio to text

Voice messages and audio files sent in chat arrive with a download URL. Use the
transcribe command from your system prompt — it fetches the file with the right
token and prints the transcript. Don't download the file yourself.

The transcript is text like any other: summarise it, answer from it, or act on
it. Only send the raw transcript back if that's what was asked for.

### Create a video from text

Slow — a few minutes — so it is three steps, not one call. Do them in order.

**1. Start it, and tell the user.** Keep the id you get back.

```bash
python -c "
from utils.video import submit_video
print(submit_video('A red balloon drifting over a green field, cinematic', seconds=5))
"
```

`seconds` must be **4 to 12** — anything else is refused. Output is always a
1280x720 landscape MP4; resolution and orientation can't be changed.

**2. Check on it every 15 seconds** until you get a `video_url`. Checking is
free, so keep the interval at 15s — don't stretch it out to save calls. A
`"status": "failed"` means stop, not keep waiting.

```bash
sleep 15 && python -c "
from utils.video import check_video
print(check_video('PASTE_THE_ID'))
"
```

**3. Download it, then upload it to the user.**

```bash
python -c "
from utils.video import download_video
print(download_video('PASTE_THE_URL', 'balloon.mp4'))
"
```

Don't give up after a few checks — it takes a while, and that is not a failure.
If your run is cut short, the id still works later: the clip is already paid
for. Whatever you hand off to the next run, put the **video_id** in it — a
fresh submit is a second charge and a different clip.

**Every attempt costs money, including one the content filter refuses.** The
filter is strict and not always consistent, so an innocent prompt is
occasionally rejected. Reword it and try **once** more, then tell the user what
happened — never retry in a loop.

### Send the result to the user

A file on disk is not a delivered result. Upload it, and say what it is:

```bash
python messaging/slack/interface.py upload logo.png -m "Here's the logo — happy to adjust the colour"
```

### If it goes wrong

- **500 / 502 / 503** — the gateway wobbled. The image and speech helpers retry
  on their own; a video submit does not. If it still fails, wait a few seconds
  and try once more, then tell the user rather than looping.
- **Video generation failed / content flagged** — the filter refused the prompt.
  Reword it and try once more, then tell the user. Never loop: each attempt is
  charged whether or not you get a clip.
- **"No video MCP server is registered"** — video isn't switched on in this
  environment. Retrying won't help; say so and offer an image instead.
- **Words in the image came out wrong** — put the exact text in quotes in the
  prompt and add `--quality high`.
- **An edit changed something it shouldn't** — list what to preserve in the
  prompt and repeat that list every time you iterate.
- **Close but not right** — make one small change per attempt instead of
  rewriting the whole prompt.

For image prompt structure and the techniques that most affect quality, read
`reference/IMAGE_PROMPTING.md` in this skill folder.
