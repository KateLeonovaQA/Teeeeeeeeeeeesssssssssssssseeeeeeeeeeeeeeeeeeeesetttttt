# Image prompting

Read this when a first attempt isn't good enough, or the job is fussy — text in
the image, a specific identity to preserve, several references to combine.

## Structure

Describe things in this order. Anything you leave out, the model decides for you:

```
[Subject + adjectives] doing [action] in [scene].
[Composition / camera]. [Lighting / mood]. [Style / medium].
[Exact text, in quotes]. [Aspect ratio or use].
```

Example:

> A weathered fisherman mending a net on a harbour wall at dawn. Three-quarter
> portrait, 85mm lens, shallow depth of field. Soft cold morning light, mist over
> the water. Photorealistic. Landscape.

## Text inside images

Put the exact words in quotes, and say how they should look:

> Poster with the headline "FRESH & CLEAN" in bold sans-serif, white on charcoal,
> centred at the top.

Add `--quality high` whenever the image contains words, small labels, or a chart.
If a word keeps coming out wrong, spell it letter by letter in the prompt.

## Working with references

Number every reference and say how they relate. Order matches the order you pass
them (`--ref` first, then `--ref-dir` alphabetically):

> Image 1 is the product. Image 2 is the background texture. Place the product
> from Image 1 centred on the texture from Image 2, with a soft contact shadow.

**Always say what must not change.** Models drift on every pass, so repeat the
preserve list each time you iterate:

> Keep the face, hair, pose and brand logo exactly as in Image 1. Change only
> the jacket colour to olive green.

## Iterating

One small change per attempt beats a full rewrite — "make the lighting warmer",
"remove the extra tree", "move the logo to the bottom right". Rewriting
everything usually loses what already worked.

For a character or product that must look the same across many images, generate
one good "anchor" image first, then pass it as a reference to every later one.

## Recipes

| Job | What matters most |
|---|---|
| Logo | "flat design, minimal strokes, strong silhouette, plain background, no watermark" |
| Infographic or diagram | `--quality high`, portrait `1024x1536`, name each labelled section and arrow |
| Product on white | "centred product, crisp silhouette, subtle contact shadow", `--quality medium` |
| Advert with copy | Quote the copy exactly, specify typeface weight, colour and position |
| Localising a design | `edit` with the original as the only reference: "Translate the text to Spanish. Change nothing else." |
| Photorealism | Name a lens (50mm, 85mm) and real light ("golden hour"), ask for texture — pores, fabric wear, small imperfections |
| Virtual try-on | Lock identity: "do not change the face, skin tone or pose". Change only the clothing |
